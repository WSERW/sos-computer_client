let modalTriger = document.querySelector('#navTriger')
let modalForm = document.querySelector('#navModal')
let modalContent = document.querySelector('#navModal > .nav_list')
modalTriger.addEventListener('click', function(){
    document.body.style.overflowY = "hidden"
    modalForm.classList.toggle("active")
    setTimeout(function(){
        modalContent.classList.toggle('active')
    }, 10);
})
const swiper = new Swiper('.swiper', {
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
    effect: 'cards',
    cardsEffect: {
        slideShadows: false,
        rotate: false,
        perSlideOffset: 8,
    },
    loop: true,
    slidesPerView: 1,
});
